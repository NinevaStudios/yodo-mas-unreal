//
//  AppLovinQualityService.h
//  AppLovinQualityService
//
//  Copyright © 2020 AppLovin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppLovinQualityService : NSObject

+(NSString*)getVersion;

@end
