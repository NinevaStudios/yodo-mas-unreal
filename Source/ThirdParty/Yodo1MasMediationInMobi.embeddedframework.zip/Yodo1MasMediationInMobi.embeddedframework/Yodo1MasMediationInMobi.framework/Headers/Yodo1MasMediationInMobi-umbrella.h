#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "Yodo1MasInMobiAdapter.h"
#import "Yodo1MasInMobiBannerAdapter.h"

FOUNDATION_EXPORT double Yodo1MasMediationInMobiVersionNumber;
FOUNDATION_EXPORT const unsigned char Yodo1MasMediationInMobiVersionString[];

