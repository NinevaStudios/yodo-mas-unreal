#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "Yodo1MasAppLovinAdapter.h"
#import "Yodo1MasAppLovinBannerAdapter.h"
#import "Yodo1MasAppLovinMaxAdapter.h"
#import "Yodo1MasAppLovinMaxBannerAdapter.h"

FOUNDATION_EXPORT double Yodo1MasMediationApplovinVersionNumber;
FOUNDATION_EXPORT const unsigned char Yodo1MasMediationApplovinVersionString[];

