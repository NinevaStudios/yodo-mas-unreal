//
//  Yodo1MasAppLovinMaxBannerAdapter.h
//  Yodo1MasMediationApplovin
//
//  Created by 周玉震 on 2021/11/23.
//

#import "Yodo1MasBannerAdapterBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasAppLovinMaxBannerAdapter : Yodo1MasBannerAdapterBase

@end

NS_ASSUME_NONNULL_END
