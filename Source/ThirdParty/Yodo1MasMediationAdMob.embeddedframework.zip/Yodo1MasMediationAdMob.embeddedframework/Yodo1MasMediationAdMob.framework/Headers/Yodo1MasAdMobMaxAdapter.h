//
//  Yodo1MasAdMobMaxAdapter.h
//  FBSDKCoreKit
//
//  Created by ZhouYuzhen on 2020/12/3.
//

#import "Yodo1MasAdMobAdapter.h"

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasAdMobMaxAdapter : Yodo1MasAdMobAdapter

@end

NS_ASSUME_NONNULL_END
