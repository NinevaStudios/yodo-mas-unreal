//
//  BUThreadSafeMutableArray.h
//  BUAdSDK
//
//  Created by 李盛 on 2019/1/3.
//  Copyright © 2019 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BUThreadSafeMutableArray : NSMutableArray

@end

NS_ASSUME_NONNULL_END
