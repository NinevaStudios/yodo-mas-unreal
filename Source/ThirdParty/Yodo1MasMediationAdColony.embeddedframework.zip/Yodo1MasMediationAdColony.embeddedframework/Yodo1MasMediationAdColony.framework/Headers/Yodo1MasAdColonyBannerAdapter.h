//
//  Yodo1MasAdColonyBannerAdapter.h
//  Yodo1MasMediationAdColony
//
//  Created by 周玉震 on 2021/11/22.
//

#import "Yodo1MasBannerAdapterBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasAdColonyBannerAdapter : Yodo1MasBannerAdapterBase

@end

NS_ASSUME_NONNULL_END
