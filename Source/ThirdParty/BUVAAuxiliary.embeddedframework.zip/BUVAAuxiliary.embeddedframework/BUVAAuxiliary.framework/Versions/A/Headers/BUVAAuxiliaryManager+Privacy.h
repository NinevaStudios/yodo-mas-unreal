//
//  BUVAAuxiliaryManager+Privacy.h
//  BUVAAuxiliary
//
//  Created by bytedance on 2020/9/2.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <BUVAAuxiliary/BUVAAuxiliary.h>

NS_ASSUME_NONNULL_BEGIN

@interface BUVAAuxiliaryManager (Privacy)

@end

NS_ASSUME_NONNULL_END
